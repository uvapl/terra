import warnings


class DessertWarning(UserWarning):
    __module__ = "dessert"


class DessertAssertRewriteWarning(DessertWarning):
    __module__ = "dessert"
